from Tkinter import *
mGui=Tk()

menubar=Menu(mGui)
#Filmenu
filemenu=Menu(menubar,tearoff=0)
filemenu.add_command(label="New")
filemenu.add_command(label="Open")
filemenu.add_command(label="Save")
menubar.add_cascade(label="File",menu=filemenu)
menubar.add_separator()
menubar.add_separator()
menubar.add_separator()

#About
about=Menu(menubar,tearoff=0)
menubar.add_cascade(label="About",menu=about)
menubar.add_separator()
menubar.add_separator()
menubar.add_separator()

#HelpMenu
helpmenu=Menu(menubar,tearoff=0)
menubar.add_cascade(label="Help",menu=helpmenu)
menubar.add_separator()
menubar.add_separator()
menubar.add_separator()

#History
history=Menu(menubar,tearoff=0)
menubar.add_cascade(label="History",menu=history)
menubar.add_separator()
menubar.add_separator()
menubar.add_separator()

#Exit
exitbt=Menu(menubar,tearoff=0)
menubar.add_cascade(label="Exit",menu=exitbt)
menubar.add_separator()
menubar.add_separator()
menubar.add_separator()



mGui.config(menu=menubar)
mGui.mainloop() 
