from Tkinter import *
from pyowm import OWM
import ttk
import requests, json
from datetime import datetime, date, timedelta
import base64
import urllib
from weather import * #python file made to retrieve data from openweathermaps
#from sugg import *
import re



def go():
    city = box.get()
    print city
    main = Toplevel()#same as frame but a new window
    main.geometry('450x450+200+200')
    Title = city
    main.title(Title)
    main.geometry("{0}x{1}+0+0".format(main.winfo_screenwidth(), main.winfo_screenheight()))
    main.resizable(width=False, height=False)
    screen_width = main.winfo_screenwidth()
    screen_height = main.winfo_screenheight()
    print screen_width , screen_height
    #background image
    #back_label = Label(main,image=back_img2)
    #back_label.place(x=0, y=0, relwidth=1, relheight=1)
    #lab = Label(main,text = city,font=("Comic Sans MS",20),fg="Red",bg="light blue").place(relx=0.5,rely=0.1,anchor=CENTER)
    #lab = Label(main,text = tmp,font=("Comic Sans MS",20),fg="Red",bg="light blue").place(relx=0.5,rely=0.3,anchor=CENTER)

    
    #using API
    dic = get(city) #create dictionary
    tmp = dic['today']['temp']
    tmp_min = dic['today']['min']
    tmp_max = dic['today']['max']
    t = tmp
    tmp = str(tmp) + "°C"
    tmp_min = "Min : " + str(tmp_min) + "°C"
    tmp_max = "Max : " + str(tmp_max) + "°C"
    ids2 = {1:0,2:1,3:2,4:3,9:4,10:5,11:6,13:7,50:8}
    

    #using CANVAS and dividing screen to 15 parts on width and height, hence 1/15 = 0.066667
    canvas = Canvas(main,width = 1920,height = 1080)
    canvas.create_image(0, 0, anchor=NW, image=back_img2)
    canvas.create_text(screen_width/2,screen_height*0.066667,text=city,fill="white",font="Sans 60 bold")
    #current weather icon
    canvas.create_image(screen_width/2, screen_height*0.066667*3.5,image=icons2[ids2[int(dic['today']['icon'][0:2])]])
    canvas.create_text(screen_width/2,screen_height*6*0.066667,text=tmp,fill="white",font="Sans 40 bold")
    canvas.create_text(screen_width*0.066667*4,screen_height*5.5*0.066667,text=tmp_min,fill="white",font="Sans 30 bold")
    canvas.create_text(screen_width*0.066667*11,screen_height*5.5*0.066667,text=tmp_max,fill="white",font="Sans 30 bold")
    #image of thermometer
    if t <= 2:
         canvas.create_image(screen_width/12, screen_height*2*0.066667*3.5,image=therm1)   
    elif t <= 15:
         canvas.create_image(screen_width/12, screen_height*2*0.066667*3.5,image=therm2)
    elif t <= 25:
         canvas.create_image(screen_width/12, screen_height*2*0.066667*3.5,image=therm3)
    elif t <= 35:
         canvas.create_image(screen_width/12, screen_height*2*0.066667*3.5,image=therm4)
    else :
         canvas.create_image(screen_width/12, screen_height*2*0.066667*3.5,image=therm5)

    canvas.create_text(screen_width/2,screen_height*7.2*0.066667,text=dic['today']['desc'],fill="white",font="Sans 40 bold")
    canvas.create_line(screen_width/5, screen_height*8*0.066667,screen_width/1.2,screen_height*8*0.066667,fill="white",width=0.1)
    canvas.create_text(screen_width/3.8,screen_height*9*0.066667,text=dic[1]['day'],fill="white",font="Sans 20 bold")
    canvas.create_text(screen_width/2.3,screen_height*9*0.066667,text=dic[2]['day'],fill="white",font="Sans 20 bold")
    canvas.create_text(screen_width/1.65,screen_height*9*0.066667,text=dic[3]['day'],fill="white",font="Sans 20 bold")
    canvas.create_text(screen_width/1.3,screen_height*9*0.066667,text=dic[4]['day'],fill="white",font="Sans 20 bold")

    #icon here
    canvas.create_image(screen_width/3.8,screen_height*10*0.066667,image=icons[ids2[int(dic[1]['icon'][0:2])]])
    canvas.create_image(screen_width/2.3,screen_height*10*0.066667,image=icons[ids2[int(dic[2]['icon'][0:2])]])
    canvas.create_image(screen_width/1.65,screen_height*10*0.066667,image=icons[ids2[int(dic[3]['icon'][0:2])]])
    canvas.create_image(screen_width/1.3,screen_height*10*0.066667,image=icons[ids2[int(dic[4]['icon'][0:2])]])

    #min and max temp for future four days
    canvas.create_text(screen_width/3.8,screen_height*11*0.066667,text=dic[1]['min'],fill="white",font="Sans 17 bold")
    canvas.create_text(screen_width/2.3,screen_height*11*0.066667,text=dic[2]['min'],fill="white",font="Sans 17 bold")
    canvas.create_text(screen_width/1.65,screen_height*11*0.066667,text=dic[3]['min'],fill="white",font="Sans 17 bold")
    canvas.create_text(screen_width/1.3,screen_height*11*0.066667,text=dic[4]['min'],fill="white",font="Sans 17 bold")
    canvas.create_text(screen_width/3.8,screen_height*11.5*0.066667,text=dic[1]['max'],fill="white",font="Sans 17 bold")
    canvas.create_text(screen_width/2.3,screen_height*11.5*0.066667,text=dic[2]['max'],fill="white",font="Sans 17 bold")
    canvas.create_text(screen_width/1.65,screen_height*11.5*0.066667,text=dic[3]['max'],fill="white",font="Sans 17 bold")
    canvas.create_text(screen_width/1.3,screen_height*11.5*0.066667,text=dic[4]['max'],fill="white",font="Sans 17 bold")
    
    canvas.pack()
    return
win = Tk()
combostyle = ttk.Style()

combostyle.theme_create('combostyle', parent='alt',
                         settings = {'TCombobox':
                                     {'configure':
                                      {'selectbackground': 'grey',
                                       'fieldbackground': 'white',
                                       'background': 'light blue'
                                       }}}
                         )
combostyle.theme_use('combostyle') 
win.geometry("{0}x{1}+0+0".format(win.winfo_screenwidth(), win.winfo_screenheight()))
win.resizable(width=False, height=False)
#win.geometry('screen_widthxscreen_height')
win.title('Weather Reporter')
back_img2 = PhotoImage(file="gradient_wallpaper_1.gif")
#background image
back_img = PhotoImage(file="backk.png")
icon1 = PhotoImage(file="PNG/simple_weather_icon_13.png")
back_label = Label(win,image=back_img)
back_label.place(x=0, y=0, relwidth=1, relheight=1)
#download icons
'''ids1 = (1,2,3,4,9,10,11,13,50)
k = 0
for i in range(1,51):
    if i in ids1:
        if(i < 10):
            num = "0" + str(i)
        else:
            num = str(i)
        URL = "http://openweathermap.org/img/w/" + num + "d.png"
        u = urllib.urlopen(URL)
        raw_data = u.read()
        u.close()
        b64_data = base64.encodestring(raw_data)
        icon = PhotoImage(data=b64_data)
        icons.insert(k,icon)
        k += 1'''
#thermometer images
therm1 = PhotoImage(file="PNG/simple_weather_icon_51.png")
therm2 = PhotoImage(file="PNG/simple_weather_icon_52.png")
therm3 = PhotoImage(file="PNG/simple_weather_icon_53.png")
therm4 = PhotoImage(file="PNG/simple_weather_icon_54.png")
therm5 = PhotoImage(file="PNG/simple_weather_icon_55.png")

#small weather icons
i1 = PhotoImage(file="icons/01d.png")
i2 = PhotoImage(file="icons/02d.png")
i3 = PhotoImage(file="icons/03d.png")
i4 = PhotoImage(file="icons/04d.png")
i5 = PhotoImage(file="icons/09d.png")
i6 = PhotoImage(file="icons/10d.png")
i7 = PhotoImage(file="icons/11d.png")
i8 = PhotoImage(file="icons/13d.png")
i9 = PhotoImage(file="icons/50d.png")
icons = [i1,i2,i3,i4,i5,i6,i7,i8,i9]

#big weather icons
ii1 = PhotoImage(file="big_icons/01d.png")
ii2 = PhotoImage(file="big_icons/02d.png")
ii3 = PhotoImage(file="big_icons/03d.png")
ii4 = PhotoImage(file="big_icons/04d.png")
ii5 = PhotoImage(file="big_icons/09d.png")
ii6 = PhotoImage(file="big_icons/10d.png")
ii7 = PhotoImage(file="big_icons/11d.png")
ii8 = PhotoImage(file="big_icons/13d.png")
ii9 = PhotoImage(file="big_icons/50d.png")
icons2 = [ii1,ii2,ii3,ii4,ii5,ii6,ii7,ii8,ii9]
#combobox
value = StringVar()
box = ttk.Combobox(win,width=30,font = "Helvetica 23 bold",textvariable=value,state = 'normal')
lis = ["London","Chandigarh","japan","china","nepal","antarctica"]
lis.sort()
lis.insert(0,"Enter the city ...")
box['values'] = lis
box.current(0)
box.place(relx=0.5,rely=0.5,anchor=CENTER)
#to retrieve the selected item from combobox use get()
print box.get()

#GO button
button_img = PhotoImage(file="button1.gif")
b = Button(text="",command=go,width=50,height=50,font=("Comic sans ms",10,"bold"),image=button_img,compound=RIGHT,bg="light blue",relief=RIDGE).place(relx=0.5,rely=0.55,anchor=CENTER)


#mainloop
win.mainloop()

